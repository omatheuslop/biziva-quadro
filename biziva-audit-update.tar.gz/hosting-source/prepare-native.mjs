import {cp,mkdir,rename,rm} from 'node:fs/promises';
import {resolve,join} from 'node:path';
import {fileURLToPath} from 'node:url';
const host=fileURLToPath(new URL('.',import.meta.url));
const root=resolve(process.argv[2] || join(host,'..'));
const target=join(host,'public');
await rm(target,{recursive:true,force:true}); await mkdir(target,{recursive:true});
const selected=null;
if(selected) for(const item of selected) await cp(join(root,item),join(target,item),{recursive:true});
else await cp(join(root,"excalidraw-app/build"),target,{recursive:true});
await rename(join(target,'index.html'),join(target,'native-index.html'));
console.log('Native assets prepared.');

await import('./apply-branding.mjs');
