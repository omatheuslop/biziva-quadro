import{readFile,writeFile,copyFile}from'node:fs/promises';const root=new URL('./',import.meta.url);await copyFile(new URL('branding/shell.html',root),new URL('public/biziva-shell.html',root));for(const f of ['biziva-theme.css','biziva-favicon.svg'])await copyFile(new URL('branding/'+f,root),new URL('public/'+f,root));const file=new URL('public/native-index.html',root);let s=await readFile(file,'utf8');if(!s.includes('/biziva-theme.css'))s=s.replace('</head>','<link rel="stylesheet" href="/biziva-theme.css"><link rel="icon" href="/biziva-favicon.svg" type="image/svg+xml"></head>');const shell=await readFile(new URL('branding/shell.html',root),'utf8');
const style=shell.match(/<style>([\s\S]*?)<\/style>/)[1];
const header=shell.match(/<header class="bar">[\s\S]*?<\/header>/)[0];
if(!s.includes('id="biziva-native-bar"')){
 s=s.replace('</head>','<style>'+style+'\nhtml,body{height:100%;overflow:hidden}body{display:flex;flex-direction:column}#root{height:calc(100% - 64px);min-height:0;flex:1}.bar{flex-shrink:0}body>header:not(.bar){position:absolute}</style></head>');
 s=s.replace('</body>',shell.slice(shell.indexOf('<dialog '),shell.lastIndexOf('</body>'))+'</body>');
 s=s.replace('<body>','<body><div id="biziva-native-bar">'+header+'</div>');
 s=s.replace('#root{height:calc(100% - 64px);','#biziva-native-bar{flex-shrink:0}#root{height:calc(100% - 64px);');
}
await writeFile(file,s);
